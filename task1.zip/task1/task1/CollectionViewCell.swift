//
//  CollectionViewCell.swift
//  task1
//
//  Created by Noura Khaled on 10/12/2018.
//  Copyright © 2018 Noura Almugarri. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var butterflyImage: UIImageView!
}
